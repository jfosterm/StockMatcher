# API Keys
fmp_api_key = "FMP_API_KEY"
NEWS_API_KEY = "NEWS_API_KEY"

# Constants
MIN_MARKET_CAP = 1e9  # $1 billion
UPDATE_INTERVAL = 30  # Minutes
